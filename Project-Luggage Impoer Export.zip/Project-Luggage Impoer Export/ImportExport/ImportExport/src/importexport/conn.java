package importexport;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import javax.swing.JOptionPane;


public class conn {
    Connection c;
    Statement s;
    
    public conn(){  
        try{  
            Class.forName("com.mysql.cj.jdbc.Driver");  
            c =DriverManager.getConnection("jdbc:mysql://localhost/ei","root",""); 
         //   if(c.isClosed())
         //   {
         //      JOptionPane.showMessageDialog(null, "Connection not Open"); 
         //   }
            s =c.createStatement();  
            
           
        }catch(Exception e){ 
            JOptionPane.showMessageDialog(null,e);
        }  
    }  
}