package importexport;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class Importor extends javax.swing.JFrame {

    public Importor() {
     
    }
    
    String Uid;
    
    public Importor(String iid) {
           initComponents();
//           jButton1.setEnabled(false);
        Uid = iid;
        try{
                conn c  = new conn();
                String displayCustomersql = "SELECT `User Name` FROM `account` WHERE `Account Type` = 'Exportor'";
                ResultSet rs = c.s.executeQuery(displayCustomersql);
                while(rs.next())
                {
                    jComboBox3.addItem(rs.getNString("User Name"));
                }
            }
           catch(SQLException e)
            {
            JOptionPane.showMessageDialog(null, e);
            }
        
    }
    
    float w,p,q;
    String n,w1,q1,p1;

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        dbill = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        we = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        pr = new javax.swing.JLabel();
        qt = new javax.swing.JLabel();
        jComboBox2 = new javax.swing.JComboBox<>();
        jLabel8 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jComboBox3 = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        odq = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        dbill.setBackground(new java.awt.Color(255, 0, 51));
        dbill.setFont(new java.awt.Font("Tahoma", 3, 12)); // NOI18N
        dbill.setForeground(new java.awt.Color(255, 255, 153));
        dbill.setText("ADD");
        dbill.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dbillActionPerformed(evt);
            }
        });
        getContentPane().add(dbill, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 390, 130, 33));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/importexport/impotor.jpg"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 10, 290, 190));

        we.setBackground(new java.awt.Color(255, 255, 255));
        we.setFont(new java.awt.Font("Tahoma", 3, 14)); // NOI18N
        we.setForeground(new java.awt.Color(51, 0, 204));
        we.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        we.setOpaque(true);
        getContentPane().add(we, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 290, 170, 25));

        jLabel7.setBackground(new java.awt.Color(255, 0, 51));
        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 153));
        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel7.setText("Select Product");
        jLabel7.setOpaque(true);
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 260, 140, 25));

        pr.setBackground(new java.awt.Color(255, 255, 255));
        pr.setFont(new java.awt.Font("Tahoma", 3, 14)); // NOI18N
        pr.setForeground(new java.awt.Color(51, 0, 204));
        pr.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        pr.setOpaque(true);
        getContentPane().add(pr, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 320, 170, 25));

        qt.setBackground(new java.awt.Color(255, 255, 255));
        qt.setFont(new java.awt.Font("Tahoma", 3, 14)); // NOI18N
        qt.setForeground(new java.awt.Color(51, 0, 204));
        qt.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        qt.setOpaque(true);
        getContentPane().add(qt, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 350, 170, 25));

        jComboBox2.setBackground(new java.awt.Color(255, 0, 0));
        jComboBox2.setForeground(new java.awt.Color(255, 255, 153));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select" }));
        jComboBox2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox2ActionPerformed(evt);
            }
        });
        getContentPane().add(jComboBox2, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 260, 170, -1));

        jLabel8.setBackground(new java.awt.Color(255, 0, 51));
        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 153));
        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel8.setText("Select Exportor");
        jLabel8.setOpaque(true);
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 230, 140, 25));

        jLabel2.setBackground(new java.awt.Color(255, 0, 51));
        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 153));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel2.setText("Weight Per Item");
        jLabel2.setOpaque(true);
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 290, 140, 25));

        jComboBox3.setBackground(new java.awt.Color(255, 0, 0));
        jComboBox3.setForeground(new java.awt.Color(255, 255, 153));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select" }));
        jComboBox3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox3ActionPerformed(evt);
            }
        });
        getContentPane().add(jComboBox3, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 230, 170, -1));

        jLabel4.setBackground(new java.awt.Color(255, 0, 51));
        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 153));
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel4.setText("Price Per Item");
        jLabel4.setOpaque(true);
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 320, 140, 25));

        jLabel6.setBackground(new java.awt.Color(255, 0, 51));
        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 153));
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel6.setText("Order Quantity");
        jLabel6.setOpaque(true);
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 400, 140, 25));

        jLabel5.setBackground(new java.awt.Color(255, 0, 51));
        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 153));
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel5.setText("Available Quantity");
        jLabel5.setOpaque(true);
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 350, 140, 25));
        getContentPane().add(odq, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 400, 170, 20));

        jTable1.setBorder(new javax.swing.border.MatteBorder(null));
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Product Name", "Available Quantity", "Bill Per Item", "Ordered Quantity", "Total Bill"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 440, 640, 130));

        jButton1.setText("Generate Order");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 580, -1, 30));

        pack();
    }// </editor-fold>//GEN-END:initComponents
int count=0;
    private void dbillActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dbillActionPerformed
        String pro = jComboBox2.getSelectedItem().toString();
        String oq1 = odq.getText();
        int oq = Integer.parseInt(oq1);
        float tbill = oq*p;
        String tb1 = String.valueOf(tbill);
        
        String A[]={pro,q1,p1,oq1,tb1};
        DefaultTableModel tb = (DefaultTableModel) jTable1.getModel();
        for (int row=0; row<tb.getRowCount(); row++)
        {
            if (pro.equals(tb.getValueAt(row, 0)))
            {
            count++;
            }
        }
        if(count==0)
        tb.addRow(A);
        else
        {
            count=0;
            JOptionPane.showMessageDialog(null, "Row Already Exists!!!");            
        }

    }//GEN-LAST:event_dbillActionPerformed

    private void jComboBox3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox3ActionPerformed
       try{
                jComboBox3.setEnabled(false);
                
                conn c  = new conn();
                String displayCustomersql = "SELECT `ProductName` FROM `exp` INNER JOIN `account` on `account`.`NTN` = `exp`.`ENTN` WHERE `account`.`User Name` = '"+jComboBox3.getSelectedItem()+"'";
                ResultSet rs = c.s.executeQuery(displayCustomersql);
                while(rs.next())
                {
                    jComboBox2.addItem(rs.getNString("ProductName"));
                }
            }
           catch(SQLException e)
            {
            JOptionPane.showMessageDialog(null, e);
            }     
    }//GEN-LAST:event_jComboBox3ActionPerformed

    
    
    private void jComboBox2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox2ActionPerformed
            try{
                conn c  = new conn();
                String displayCustomersql = "SELECT `PWeight`, `AQty`, `PPItem`, `ENTN` FROM `exp` INNER JOIN `account` on `account`.`NTN` = `exp`.`ENTN` WHERE `account`.`User Name` = '"+jComboBox3.getSelectedItem()+"' AND `ProductName` = '"+jComboBox2.getSelectedItem()+"'";
                ResultSet rs = c.s.executeQuery(displayCustomersql);
                rs.next();
                
                w = rs.getFloat("PWeight");
                q = rs.getFloat("AQty");
                p = rs.getFloat("PPItem");
                n = rs.getNString("ENTN");
                
                w1 = String.valueOf(w);
                q1 = String.valueOf(q);
                p1 = String.valueOf(p);
                
                we.setText(w1);
                qt.setText(q1);
                pr.setText(p1);
            }
           catch(SQLException e)
            {
            JOptionPane.showMessageDialog(null, e);
            }
    }//GEN-LAST:event_jComboBox2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        try
        {
            conn C = new conn();
            String ts = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Timestamp(System.currentTimeMillis()));
            String str = "INSERT INTO `order` (`DandT`, `iid`, `Eid`) VALUES ('"+ts+"', '"+Uid+"', '"+n+"')";
            C.s.executeUpdate(str);
            JOptionPane.showMessageDialog(null, "Order Created Successfully!!!");
            //this.setVisible(false);
            
            
            
                    Connection con = null; 

  Statement st1 = null; 

  Statement st2 = null; 

  ResultSet rs1 = null; 

  ResultSet rs2 = null; 

  String url = "jdbc:mysql://localhost/"; 

  String db = "ei"; 

  String driver = "com.mysql.jdbc.Driver"; 

  String user = "root"; 

  String pass = ""; 
    Class.forName(driver);

  con = DriverManager.getConnection(url + db, user, pass);

  st1 = con.createStatement();

  st2 = con.createStatement();
  
  String sql = "SELECT max(`Oid`) AS 'MO' FROM `order`";
  rs1 = st1.executeQuery(sql);
   rs1.next();
  int oid = rs1.getInt("MO");         
            
            
            
            
            
//            String q21 = "SELECT max(`Oid`) AS 'MO' FROM `order`";
//            conn cn2 = new conn();
//            ResultSet rs22 = cn2.s1.executeQuery(q21);
//            rs22.next();
//            int oid = rs22.getInt("MO");
//            int oid = Integer.parseInt(sd);
            
            
            String c1,c2,c3,c4,c5;
            
            DefaultTableModel tb = (DefaultTableModel) jTable1.getModel();
            for (int row=0; row<tb.getRowCount(); row++)
            {
                   c1 = tb.getValueAt(row, 0).toString();
                   c2 = tb.getValueAt(row, 1).toString();
                   c3 = tb.getValueAt(row, 2).toString();
                   c4 = tb.getValueAt(row, 3).toString();
                   c5 = tb.getValueAt(row, 4).toString();
                   
                String str2 = "INSERT INTO `orderdetail`(`Oid`, `ProductName`, `Eid`, `OQty`, `BillPerItem`, `TB`) VALUES ('"+oid+"', '"+c1+"', '"+n+"', '"+ Float.parseFloat(c4)+"', '"+Float.parseFloat(c3)+"', '"+Float.parseFloat(c5)+"')";
                st2.executeUpdate(str2);
            }
            
            JOptionPane.showMessageDialog(null, "Your Order Number is "+oid+"\nOrder Details Entered Successful!!!");
            BillDetails bdd;
            bdd = new BillDetails(n,Uid,oid);
            bdd.setVisible(true);
            this.setVisible(false);
        }
        catch(Exception e)
        {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, e);
        }
        
        
        
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Importor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Importor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Importor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Importor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Importor().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton dbill;
    private javax.swing.JButton jButton1;
    private javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JComboBox<String> jComboBox3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField odq;
    private javax.swing.JLabel pr;
    private javax.swing.JLabel qt;
    private javax.swing.JLabel we;
    // End of variables declaration//GEN-END:variables
}
