-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 12, 2021 at 08:25 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.3.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ei`
--

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE `account` (
  `NTN` varchar(20) NOT NULL,
  `User Name` varchar(20) NOT NULL,
  `Company Name` varchar(30) NOT NULL,
  `Loc` varchar(50) NOT NULL,
  `Contact` varchar(20) NOT NULL,
  `Account Type` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `account`
--

INSERT INTO `account` (`NTN`, `User Name`, `Company Name`, `Loc`, `Contact`, `Account Type`, `password`) VALUES
('1121123132111', 'Ali Raza', 'Loin Limited', 'Islamabad', '03331231231', 'Importor', '12345'),
('3733302112341', 'Aslam', 'Cheeta PVT Limited', 'Lahore', '03058978111', 'Exportor', '1122');

-- --------------------------------------------------------

--
-- Table structure for table `exp`
--

CREATE TABLE `exp` (
  `ProductName` varchar(20) NOT NULL,
  `PWeight` float NOT NULL,
  `AQty` float NOT NULL,
  `PPItem` float NOT NULL,
  `ENTN` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `exp`
--

INSERT INTO `exp` (`ProductName`, `PWeight`, `AQty`, `PPItem`, `ENTN`) VALUES
('Cloth', 1, 50, 1000, '3733302112341'),
('Data Cable', 0.12, 500, 80, '3733302112341');

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE `order` (
  `Oid` int(11) NOT NULL,
  `DandT` varchar(20) NOT NULL,
  `iid` varchar(20) NOT NULL,
  `Eid` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `order`
--

INSERT INTO `order` (`Oid`, `DandT`, `iid`, `Eid`) VALUES
(15, '2021.06.12.23.02.10', '1121123132111', '3733302112341');

-- --------------------------------------------------------

--
-- Table structure for table `orderdetail`
--

CREATE TABLE `orderdetail` (
  `Oid` int(11) NOT NULL,
  `ProductName` varchar(20) NOT NULL,
  `Eid` varchar(20) NOT NULL,
  `OQty` float NOT NULL,
  `BillPerItem` float NOT NULL,
  `TB` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orderdetail`
--

INSERT INTO `orderdetail` (`Oid`, `ProductName`, `Eid`, `OQty`, `BillPerItem`, `TB`) VALUES
(15, 'Cloth', '3733302112341', 10, 1000, 10000),
(15, 'Data Cable', '3733302112341', 100, 80, 8000);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account`
--
ALTER TABLE `account`
  ADD PRIMARY KEY (`NTN`);

--
-- Indexes for table `exp`
--
ALTER TABLE `exp`
  ADD KEY `ENTN` (`ENTN`);

--
-- Indexes for table `order`
--
ALTER TABLE `order`
  ADD PRIMARY KEY (`Oid`),
  ADD KEY `iid` (`iid`),
  ADD KEY `Eid` (`Eid`);

--
-- Indexes for table `orderdetail`
--
ALTER TABLE `orderdetail`
  ADD KEY `Oid` (`Oid`),
  ADD KEY `Eid` (`Eid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `order`
--
ALTER TABLE `order`
  MODIFY `Oid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `exp`
--
ALTER TABLE `exp`
  ADD CONSTRAINT `exp_ibfk_1` FOREIGN KEY (`ENTN`) REFERENCES `account` (`NTN`);

--
-- Constraints for table `order`
--
ALTER TABLE `order`
  ADD CONSTRAINT `order_ibfk_1` FOREIGN KEY (`iid`) REFERENCES `account` (`NTN`),
  ADD CONSTRAINT `order_ibfk_2` FOREIGN KEY (`Eid`) REFERENCES `account` (`NTN`);

--
-- Constraints for table `orderdetail`
--
ALTER TABLE `orderdetail`
  ADD CONSTRAINT `orderdetail_ibfk_1` FOREIGN KEY (`Oid`) REFERENCES `order` (`Oid`),
  ADD CONSTRAINT `orderdetail_ibfk_2` FOREIGN KEY (`Eid`) REFERENCES `account` (`NTN`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
